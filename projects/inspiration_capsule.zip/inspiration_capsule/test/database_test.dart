// 数据库服务测试代码
// 运行方式: 在 Flutter 项目中使用 flutter test test/database_test.dart

import 'package:flutter_test/flutter_test.dart';
import 'package:inspiration_capsule/models/inspiration.dart';
import 'package:inspiration_capsule/services/database_service.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'dart:io';

void main() {
  // 初始化 FFI（用于桌面端测试）
  setUpAll(() {
    if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }
  });

  group('DatabaseService 测试', () {
    late DatabaseService db;

    setUp(() async {
      db = DatabaseService();
      // 测试前清理数据库
      await db.deleteDatabase();
    });

    tearDown(() async {
      await db.close();
    });

    test('插入灵感记录', () async {
      final inspiration = Inspiration.create(
        rawText: '测试原始文本',
        refinedText: '测试优化后的文本',
        tags: ['测试', '灵感'],
        category: '工作',
      );

      await db.insertInspiration(inspiration);

      final fetched = await db.getInspiration(inspiration.id);
      expect(fetched, isNotNull);
      expect(fetched!.rawText, equals('测试原始文本'));
      expect(fetched.category, equals('工作'));
      expect(fetched.tags, contains('测试'));
    });

    test('获取所有灵感记录', () async {
      final inspiration1 = Inspiration.create(
        rawText: '第一条灵感',
        refinedText: '优化后的第一条',
        category: '工作',
      );
      final inspiration2 = Inspiration.create(
        rawText: '第二条灵感',
        refinedText: '优化后的第二条',
        category: '生活',
      );

      await db.insertInspiration(inspiration1);
      await db.insertInspiration(inspiration2);

      final all = await db.getAllInspirations();
      expect(all.length, equals(2));
    });

    test('按分类查询', () async {
      final work = Inspiration.create(
        rawText: '工作灵感',
        refinedText: '工作优化',
        category: '工作',
      );
      final life = Inspiration.create(
        rawText: '生活灵感',
        refinedText: '生活优化',
        category: '生活',
      );

      await db.insertInspiration(work);
      await db.insertInspiration(life);

      final workItems = await db.getInspirationsByCategory('工作');
      expect(workItems.length, equals(1));
      expect(workItems.first.category, equals('工作'));
    });

    test('更新灵感记录', () async {
      final inspiration = Inspiration.create(
        rawText: '原始文本',
        refinedText: '优化文本',
      );

      await db.insertInspiration(inspiration);

      final updated = inspiration.copyWith(
        refinedText: '更新后的文本',
        category: '新分类',
      );

      await db.updateInspiration(updated);

      final fetched = await db.getInspiration(inspiration.id);
      expect(fetched!.refinedText, equals('更新后的文本'));
      expect(fetched.category, equals('新分类'));
    });

    test('删除灵感记录', () async {
      final inspiration = Inspiration.create(
        rawText: '要删除的文本',
        refinedText: '优化文本',
      );

      await db.insertInspiration(inspiration);
      await db.deleteInspiration(inspiration.id);

      final fetched = await db.getInspiration(inspiration.id);
      expect(fetched, isNull);
    });

    test('讨论记录增删改查', () async {
      // 先创建灵感记录
      final inspiration = Inspiration.create(
        rawText: '测试灵感',
        refinedText: '优化后',
      );
      await db.insertInspiration(inspiration);

      // 添加讨论
      final discussion1 = Discussion.create(
        role: 'user',
        content: '用户问题',
      );
      final discussion2 = Discussion.create(
        role: 'assistant',
        content: 'AI回答',
      );

      await db.insertDiscussion(inspiration.id, discussion1);
      await db.insertDiscussion(inspiration.id, discussion2);

      // 查询讨论
      final discussions = await db.getDiscussions(inspiration.id);
      expect(discussions.length, equals(2));
      expect(discussions.first.role, equals('user'));
      expect(discussions.last.role, equals('assistant'));
    });

    test('获取所有分类', () async {
      await db.insertInspiration(Inspiration.create(
        rawText: '工作1',
        refinedText: '优化1',
        category: '工作',
      ));
      await db.insertInspiration(Inspiration.create(
        rawText: '工作2',
        refinedText: '优化2',
        category: '工作',
      ));
      await db.insertInspiration(Inspiration.create(
        rawText: '生活1',
        refinedText: '优化3',
        category: '生活',
      ));

      final categories = await db.getAllCategories();
      expect(categories, contains('工作'));
      expect(categories, contains('生活'));
      expect(categories.length, equals(2));
    });

    test('分类统计', () async {
      await db.insertInspiration(Inspiration.create(
        rawText: '工作1',
        refinedText: '优化1',
        category: '工作',
      ));
      await db.insertInspiration(Inspiration.create(
        rawText: '工作2',
        refinedText: '优化2',
        category: '工作',
      ));
      await db.insertInspiration(Inspiration.create(
        rawText: '生活1',
        refinedText: '优化3',
        category: '生活',
      ));

      final stats = await db.getCategoryCounts();
      expect(stats['工作'], equals(2));
      expect(stats['生活'], equals(1));
    });
  });
}
