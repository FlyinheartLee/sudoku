import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:record/record.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:uuid/uuid.dart';
import '../providers/app_providers.dart';
import '../services/ai_service.dart';
import '../services/database_service.dart';
import '../models/inspiration.dart';
import 'refinement_screen.dart';

class InputScreen extends ConsumerStatefulWidget {
  final bool isVoice;
  
  const InputScreen({super.key, required this.isVoice});

  @override
  ConsumerState<InputScreen> createState() => _InputScreenState();
}

class _InputScreenState extends ConsumerState<InputScreen> {
  final _textController = TextEditingController();
  final _audioRecorder = AudioRecorder();
  bool _isRecording = false;
  bool _isProcessing = false;
  String _recordingPath = '';

  @override
  void dispose() {
    _textController.dispose();
    _audioRecorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.85,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // 顶部栏
          _buildHeader(),
          
          // 输入区域
          Expanded(
            child: widget.isVoice ? _buildVoiceInput() : _buildTextInput(),
          ),
          
          // 底部按钮
          _buildBottomButtons(),
          
          // 安全区域
          SizedBox(height: MediaQuery.of(context).padding.bottom),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Colors.grey[200]!)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Row(
          children: [
            Material(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(12),
              child: InkWell(
                onTap: () => Navigator.pop(context),
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  child: Icon(Icons.close, color: Colors.grey[700]),
                ),
              ),
            ),
            const Expanded(
              child: Text(
                '新想法',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(width: 48),
          ],
        ),
      ),
    );
  }

  Widget _buildVoiceInput() {
    return Container(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // 提示文字
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              color: _isRecording ? Colors.red[50] : Colors.grey[50],
              borderRadius: BorderRadius.circular(30),
            ),
            child: Text(
              _isRecording ? '正在聆听...' : '按住下方按钮开始录音',
              style: TextStyle(
                fontSize: 16,
                color: _isRecording ? Colors.red : Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          
          const SizedBox(height: 48),
          
          // 录音按钮
          GestureDetector(
            onTapDown: (_) => _startRecording(),
            onTapUp: (_) => _stopRecording(),
            onTapCancel: () => _cancelRecording(),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeInOut,
              width: _isRecording ? 200 : 160,
              height: _isRecording ? 200 : 160,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: _isRecording
                      ? [Colors.red[400]!, Colors.red[600]!]
                      : [const Color(0xFF6C63FF), const Color(0xFF8B5CF6)],
                ),
                boxShadow: [
                  BoxShadow(
                    color: (_isRecording ? Colors.red : const Color(0xFF6C63FF))
                        .withOpacity(_isRecording ? 0.4 : 0.25),
                    blurRadius: _isRecording ? 40 : 30,
                    spreadRadius: _isRecording ? 10 : 5,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _isRecording ? Icons.mic : Icons.mic_none,
                    size: _isRecording ? 72 : 56,
                    color: Colors.white,
                  ),
                  if (_isRecording) ...[
                    const SizedBox(height: 8),
                    Container(
                      width: 60,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 48),
          
          // 底部提示
          Text(
            _isRecording ? '松开结束录音' : '点击按钮，说出你的想法',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
          
          const SizedBox(height: 8),
          
          Text(
            '录音将自动转换为文字',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey[400],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextInput() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '写下你的想法',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.grey[50],
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.grey[200]!),
              ),
              child: TextField(
                controller: _textController,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                style: const TextStyle(
                  fontSize: 16,
                  height: 1.6,
                ),
                decoration: InputDecoration(
                  hintText: '灵感一闪而过，快记录下来...',
                  hintStyle: TextStyle(
                    color: Colors.grey[400],
                    fontSize: 16,
                  ),
                  contentPadding: const EdgeInsets.all(20),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomButtons() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Colors.grey[200]!)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            // 取消按钮
            Expanded(
              flex: 1,
              child: OutlinedButton.icon(
                onPressed: _isProcessing ? null : () => Navigator.pop(context),
                icon: const Icon(Icons.close),
                label: const Text('取消'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.grey[700],
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  side: BorderSide(color: Colors.grey[300]!),
                ),
              ),
            ),
            const SizedBox(width: 12),
            // 提交按钮
            Expanded(
              flex: 2,
              child: ElevatedButton.icon(
                onPressed: _isProcessing ? null : _submit,
                icon: _isProcessing
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      )
                    : const Icon(Icons.auto_fix_high),
                label: Text(_isProcessing ? 'AI 整理中...' : 'AI 整理'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF6C63FF),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  elevation: 0,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _startRecording() async {
    final status = await Permission.microphone.request();
    if (status != PermissionStatus.granted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('需要麦克风权限')),
      );
      return;
    }

    try {
      await _audioRecorder.start(const RecordConfig(), path: '');
      setState(() => _isRecording = true);
    } catch (e) {
      debugPrint('录音失败: $e');
    }
  }

  Future<void> _stopRecording() async {
    if (!_isRecording) return;
    
    setState(() => _isRecording = false);
    
    try {
      final path = await _audioRecorder.stop();
      if (path != null) {
        setState(() => _recordingPath = path);
        // 这里应该调用科大讯飞语音识别
        // 暂时用模拟文本
        _showMockTranscription();
      }
    } catch (e) {
      debugPrint('停止录音失败: $e');
    }
  }

  void _cancelRecording() {
    if (_isRecording) {
      _audioRecorder.stop();
      setState(() => _isRecording = false);
    }
  }

  void _showMockTranscription() {
    // 模拟语音转文字结果
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('语音转文字'),
        content: const TextField(
          maxLines: 5,
          decoration: InputDecoration(
            hintText: '语音识别结果（实际使用时集成科大讯飞SDK）',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('取消'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _textController.text = '刚才想到一个产品点子，关于AI语音笔记的...';
            },
            child: const Text('确认'),
          ),
        ],
      ),
    );
  }

  Future<void> _submit() async {
    final text = widget.isVoice ? _textController.text : _textController.text;
    if (text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('请输入内容')),
      );
      return;
    }

    setState(() => _isProcessing = true);

    try {
      // 调用 AI 整理
      final aiService = ref.read(aiServiceProvider);
      final result = await aiService.refineContent(text);

      if (!mounted) return;

      // 跳转到整理确认页面
      Navigator.pop(context);
      
      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => RefinementScreen(
          rawText: text,
          result: result,
        ),
      );
    } catch (e) {
      setState(() => _isProcessing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('处理失败: $e')),
      );
    }
  }
}
