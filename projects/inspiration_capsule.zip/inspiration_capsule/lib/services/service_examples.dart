import 'package:flutter/material.dart';
import '../services/ai_service.dart';
import '../services/voice_service.dart';

/// AI 服务使用示例
class AIServiceExample {
  final AIService _aiService = AIService();

  /// 示例1：使用腾讯混元
  void setupHunyuan() {
    _aiService.configure(
      config: AIConfig.hunyuan(apiKey: 'your-hunyuan-api-key'),
    );
  }

  /// 示例2：使用 Kimi
  void setupKimi() {
    _aiService.configure(
      config: AIConfig.kimi(apiKey: 'your-kimi-api-key'),
    );
  }

  /// 示例3：使用自定义 OpenAI 兼容 API
  void setupCustom() {
    _aiService.configure(
      config: AIConfig.openaiCompatible(
        baseUrl: 'https://api.example.com/v1',
        apiKey: 'your-api-key',
        model: 'gpt-4',
      ),
    );
  }

  /// 示例4：整理内容
  Future<void> exampleRefineContent() async {
    try {
      final result = await _aiService.refineContent('''
今天有一个想法，关于做一个灵感记录的应用
用户可以通过语音输入快速记录
然后 AI 会帮忙整理成结构化的笔记
这个应用应该叫做灵感胶囊
''');

      print('整理后的内容: ${result.refinedText}');
      print('标签: ${result.tags}');
      print('分类: ${result.category}');
      print('摘要: ${result.summary}');
    } on AIServiceException catch (e) {
      print('错误: ${e.message}');
    }
  }

  /// 示例5：继续讨论
  Future<void> exampleContinueDiscussion() async {
    try {
      final history = [
        {'role': 'user', 'content': '我想做一个灵感记录应用'},
        {'role': 'assistant', 'content': '这是个很棒的想法！你打算用什么技术栈？'},
      ];

      final response = await _aiService.continueDiscussion(
        history,
        '我打算用 Flutter 开发',
      );

      print('AI回复: $response');
    } on AIServiceException catch (e) {
      print('错误: ${e.message}');
    }
  }
}

/// 语音服务使用示例
class VoiceServiceExample {
  final VoiceService _voiceService = VoiceService();
  String _recognizedText = '';

  /// 示例1：初始化服务（模拟模式）
  Future<void> setupMockMode() async {
    await _voiceService.initialize(
      config: const VoiceConfig(
        isMockMode: true,  // 模拟模式
        maxDurationSeconds: 60,
        language: 'zh_cn',
      ),
    );
  }

  /// 示例2：初始化服务（科大讯飞 - 待接入）
  Future<void> setupXfyunMode() async {
    await _voiceService.initialize(
      config: const VoiceConfig(
        isMockMode: false,
        xfyunAppId: 'your-xfyun-app-id',
        xfyunApiKey: 'your-xfyun-api-key',
        xfyunApiSecret: 'your-xfyun-api-secret',
        maxDurationSeconds: 60,
        language: 'zh_cn',
      ),
    );
  }

  /// 示例3：开始录音识别
  Future<void> startRecording() async {
    _recognizedText = '';
    
    await _voiceService.startListening(
      callback: SimpleRecognitionCallback(
        onTextResult: (text, isFinal) {
          _recognizedText = text;
          print(isFinal ? '最终结果: $text' : '中间结果: $text');
        },
        onVolume: (volume) {
          // 更新音量动画
          print('音量: ${(volume * 100).toInt()}%');
        },
        onErrorCallback: (error) {
          print('识别错误: ${error.message}');
        },
      ),
    );
  }

  /// 示例4：停止录音
  Future<void> stopRecording() async {
    final result = await _voiceService.stopListening();
    print('识别完成: ${result.text}');
  }

  /// 示例5：识别本地音频文件
  Future<void> recognizeFile(String filePath) async {
    try {
      final result = await _voiceService.recognizeFile(filePath);
      print('文件识别结果: ${result.text}');
      print('置信度: ${result.confidence}');
    } on VoiceServiceException catch (e) {
      print('识别失败: ${e.message}');
    }
  }

  /// 示例6：完整录音流程（Flutter Widget 中使用）
  Widget buildRecordButton(BuildContext context) {
    return StreamBuilder<RecordingState>(
      stream: _voiceService.onStateChanged,
      builder: (context, snapshot) {
        final state = snapshot.data ?? RecordingState.idle;
        final isRecording = state == RecordingState.recording;

        return FloatingActionButton(
          onPressed: isRecording ? stopRecording : startRecording,
          child: Icon(isRecording ? Icons.stop : Icons.mic),
        );
      },
    );
  }

  /// 释放资源
  Future<void> dispose() async {
    await _voiceService.dispose();
  }
}

/// 综合使用示例：语音输入 + AI 整理
class CompleteExample {
  final VoiceService _voiceService = VoiceService();
  final AIService _aiService = AIService();

  Future<void> initialize() async {
    // 初始化语音服务（模拟模式）
    await _voiceService.initialize(config: const VoiceConfig(isMockMode: true));
    
    // 初始化 AI 服务
    _aiService.configure(config: AIConfig.hunyuan(apiKey: 'your-api-key'));
  }

  /// 完整的语音记录和整理流程
  Future<void> recordAndRefine() async {
    // 1. 开始录音
    String recognizedText = '';
    
    await _voiceService.startListening(
      callback: SimpleRecognitionCallback(
        onTextResult: (text, isFinal) {
          recognizedText = text;
        },
      ),
    );

    // 等待用户停止录音（实际应用中通过 UI 触发）
    await Future.delayed(const Duration(seconds: 5));
    
    // 2. 停止录音
    await _voiceService.stopListening();

    if (recognizedText.isEmpty) {
      print('没有识别到内容');
      return;
    }

    // 3. 使用 AI 整理内容
    try {
      final result = await _aiService.refineContent(recognizedText);
      
      print('=== 整理结果 ===');
      print(result.refinedText);
      print('标签: ${result.tags.join(', ')}');
      print('分类: ${result.category}');
    } on AIServiceException catch (e) {
      print('整理失败: ${e.message}');
    }
  }
}
