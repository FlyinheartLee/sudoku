/// ============================================================================
/// 灵感胶囊 App - Riverpod Providers 使用示例
/// ============================================================================
/// 
/// 本文件演示如何在各个页面中使用 app_providers.dart 中定义的 Providers
/// 这不是实际运行的代码，而是参考示例
///
/// ============================================================================

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'providers/app_providers.dart';
import 'models/inspiration.dart';
import 'services/ai_service.dart';

// ==================== 示例 1: 在 Widget 中读取 Providers ====================

class ExampleReaderWidget extends ConsumerWidget {
  const ExampleReaderWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 读取服务
    final dbService = ref.read(databaseServiceProvider);
    final aiService = ref.read(aiServiceProvider);

    // 监听状态（会触发 rebuild）
    final selectedCategory = ref.watch(selectedCategoryProvider);
    final searchQuery = ref.watch(searchQueryProvider);

    // 监听异步数据
    final inspirationsAsync = ref.watch(inspirationsProvider);
    final categoriesAsync = ref.watch(categoriesProvider);

    return inspirationsAsync.when(
      data: (inspirations) => ListView.builder(
        itemCount: inspirations.length,
        itemBuilder: (context, index) {
          final inspiration = inspirations[index];
          return ListTile(
            title: Text(inspiration.refinedText),
            subtitle: Text(inspiration.category),
          );
        },
      ),
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text('错误: $error')),
    );
  }
}

// ==================== 示例 2: 使用 StateNotifier 操作数据 ====================

class ExampleOperationsWidget extends ConsumerWidget {
  const ExampleOperationsWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 获取 inspirationsNotifier 用于操作数据
    final inspirationsNotifier = ref.read(inspirationsNotifierProvider.notifier);

    return Column(
      children: [
        ElevatedButton(
          onPressed: () async {
            // 添加新灵感
            final newInspiration = Inspiration(
              id: DateTime.now().toString(),
              rawText: '原始文本',
              refinedText: '整理后的文本',
              category: '灵感',
              tags: ['标签1', '标签2'],
              createdAt: DateTime.now(),
              updatedAt: DateTime.now(),
            );
            await inspirationsNotifier.addInspiration(newInspiration);
          },
          child: const Text('添加灵感'),
        ),
        
        ElevatedButton(
          onPressed: () async {
            // 删除灵感
            await inspirationsNotifier.deleteInspiration('inspiration_id');
          },
          child: const Text('删除灵感'),
        ),
        
        ElevatedButton(
          onPressed: () async {
            // 刷新列表
            await inspirationsNotifier.loadInspirations();
          },
          child: const Text('刷新列表'),
        ),
      ],
    );
  }
}

// ==================== 示例 3: 修改状态 ====================

class ExampleStateModification extends ConsumerWidget {
  const ExampleStateModification({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      children: [
        // 分类筛选
        Consumer(
          builder: (context, ref, child) {
            final categoriesAsync = ref.watch(categoriesProvider);
            final selectedCategory = ref.watch(selectedCategoryProvider);
            
            return categoriesAsync.when(
              data: (categories) => Wrap(
                spacing: 8,
                children: categories.map((cat) {
                  final isSelected = cat == selectedCategory;
                  return ChoiceChip(
                    label: Text(cat),
                    selected: isSelected,
                    onSelected: (_) {
                      // 修改选中分类
                      ref.read(selectedCategoryProvider.notifier).state = cat;
                    },
                  );
                }).toList(),
              ),
              loading: () => const CircularProgressIndicator(),
              error: (_, __) => const Text('加载分类失败'),
            );
          },
        ),
        
        // 搜索框
        TextField(
          onChanged: (value) {
            // 更新搜索关键词
            ref.read(searchQueryProvider.notifier).state = value;
          },
          decoration: const InputDecoration(
            hintText: '搜索灵感...',
            prefixIcon: Icon(Icons.search),
          ),
        ),
      ],
    );
  }
}

// ==================== 示例 4: 使用筛选后的列表 ====================

class ExampleFilteredList extends ConsumerWidget {
  const ExampleFilteredList({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // 自动根据分类和搜索词筛选
    final filteredAsync = ref.watch(filteredInspirationsProvider);

    return filteredAsync.when(
      data: (inspirations) {
        if (inspirations.isEmpty) {
          return const Center(child: Text('没有找到灵感'));
        }
        return ListView.builder(
          itemCount: inspirations.length,
          itemBuilder: (context, index) {
            final item = inspirations[index];
            return ListTile(
              title: Text(item.refinedText.substring(
                0, 
                item.refinedText.length > 50 ? 50 : item.refinedText.length
              )),
              subtitle: Text('${item.category} · ${item.tags.join(', ')}'),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text('错误: $error')),
    );
  }
}

// ==================== 示例 5: 录音状态管理 ====================

class ExampleRecordingWidget extends ConsumerWidget {
  const ExampleRecordingWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final recordingState = ref.watch(recordingStateProvider);
    final recordingDuration = ref.watch(recordingDurationProvider);

    return Column(
      children: [
        // 显示录音状态
        Text('状态: ${recordingState.name}'),
        Text('时长: ${recordingDuration}s'),
        
        // 录音按钮
        GestureDetector(
          onTapDown: (_) {
            ref.read(recordingStateProvider.notifier).state = RecordingState.recording;
          },
          onTapUp: (_) {
            ref.read(recordingStateProvider.notifier).state = RecordingState.processing;
            // 处理录音...
          },
          child: Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: recordingState == RecordingState.recording 
                ? Colors.red 
                : const Color(0xFF6C63FF),
            ),
            child: Icon(
              recordingState == RecordingState.recording ? Icons.mic : Icons.mic_none,
              color: Colors.white,
            ),
          ),
        ),
        
        // 或者使用 Notifier
        ElevatedButton(
          onPressed: () {
            final notifier = ref.read(recordingNotifierProvider.notifier);
            notifier.startRecording();
          },
          child: const Text('开始录音 (Notifier)'),
        ),
      ],
    );
  }
}

// ==================== 示例 6: AI 处理状态 ====================

class ExampleAIProcessingWidget extends ConsumerWidget {
  const ExampleAIProcessingWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final processingState = ref.watch(aiProcessingStateProvider);
    final error = ref.watch(aiErrorProvider);

    return Column(
      children: [
        if (processingState == AIProcessingState.refining)
          const LinearProgressIndicator(),
        
        if (error != null)
          Text('错误: $error', style: const TextStyle(color: Colors.red)),
        
        ElevatedButton(
          onPressed: processingState == AIProcessingState.idle
            ? () async {
                ref.read(aiProcessingStateProvider.notifier).state = 
                  AIProcessingState.refining;
                
                try {
                  final aiService = ref.read(aiServiceProvider);
                  final result = await aiService.refineContent('原始文本');
                  // 处理结果...
                  ref.read(aiProcessingStateProvider.notifier).state = 
                    AIProcessingState.completed;
                } catch (e) {
                  ref.read(aiErrorProvider.notifier).state = e.toString();
                  ref.read(aiProcessingStateProvider.notifier).state = 
                    AIProcessingState.error;
                }
              }
            : null,
          child: Text(
            processingState == AIProcessingState.refining 
              ? '整理中...' 
              : 'AI 整理'
          ),
        ),
      ],
    );
  }
}

// ==================== 示例 7: 刷新数据 ====================

class ExampleRefreshWidget extends ConsumerWidget {
  const ExampleRefreshWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Column(
      children: [
        ElevatedButton(
          onPressed: () {
            // 刷新所有灵感数据
            refreshInspirations(ref);
          },
          child: const Text('刷新灵感列表'),
        ),
        
        ElevatedButton(
          onPressed: () {
            // 刷新分类数据
            refreshCategories(ref);
          },
          child: const Text('刷新分类'),
        ),
        
        ElevatedButton(
          onPressed: () {
            // 重置筛选条件
            resetFilters(ref);
          },
          child: const Text('重置筛选'),
        ),
        
        ElevatedButton(
          onPressed: () {
            // 刷新特定灵感详情
            refreshInspirationDetail(ref, 'inspiration_id');
          },
          child: const Text('刷新详情'),
        ),
      ],
    );
  }
}

// ==================== 示例 8: 获取灵感详情 ====================

class ExampleDetailWidget extends ConsumerWidget {
  final String inspirationId;
  
  const ExampleDetailWidget({super.key, required this.inspirationId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final inspirationAsync = ref.watch(inspirationDetailProvider(inspirationId));

    return inspirationAsync.when(
      data: (inspiration) {
        if (inspiration == null) {
          return const Center(child: Text('记录不存在'));
        }
        return Column(
          children: [
            Text(inspiration.refinedText),
            Text('分类: ${inspiration.category}'),
            Wrap(
              children: inspiration.tags.map((tag) => Chip(label: Text(tag))).toList(),
            ),
            // 讨论记录
            ...inspiration.discussions.map((d) => ListTile(
              title: Text(d.content),
              subtitle: Text(d.role),
            )),
          ],
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stack) => Center(child: Text('加载失败: $error')),
    );
  }
}

// ==================== 示例 9: 使用 ConsumerStatefulWidget ====================

class ExampleStatefulWidget extends ConsumerStatefulWidget {
  const ExampleStatefulWidget({super.key});

  @override
  ConsumerState<ExampleStatefulWidget> createState() => _ExampleStatefulWidgetState();
}

class _ExampleStatefulWidgetState extends ConsumerState<ExampleStatefulWidget> {
  @override
  void initState() {
    super.initState();
    // 初始化时加载数据
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(inspirationsNotifierProvider.notifier).loadInspirations();
    });
  }

  Future<void> _handleSave(String rawText, RefinementResult result) async {
    final inspiration = Inspiration(
      id: DateTime.now().toString(),
      rawText: rawText,
      refinedText: result.refinedText,
      tags: result.tags,
      category: result.category,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    await ref.read(inspirationsNotifierProvider.notifier).addInspiration(inspiration);
    
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('保存成功')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final inspirationsState = ref.watch(inspirationsNotifierProvider);

    return Scaffold(
      body: inspirationsState.when(
        data: (inspirations) => ListView.builder(
          itemCount: inspirations.length,
          itemBuilder: (context, index) {
            final item = inspirations[index];
            return ListTile(
              title: Text(item.refinedText),
              trailing: IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () async {
                  await ref.read(inspirationsNotifierProvider.notifier)
                    .deleteInspiration(item.id);
                },
              ),
            );
          },
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(child: Text('错误: $error')),
      ),
    );
  }
}

// ==================== Provider 速查表 ====================
/*

## 服务层 Providers
- databaseServiceProvider -> DatabaseService
- aiServiceProvider -> AIService

## 数据层 Providers
- inspirationsProvider -> Future<List<Inspiration>>
- inspirationsNotifierProvider -> StateNotifier (增删改)
- categoriesProvider -> Future<List<String>>
- categoriesNotifierProvider -> StateNotifier
- inspirationDetailProvider(id) -> Future<Inspiration?>
- inspirationsByCategoryProvider(category) -> Future<List<Inspiration>>

## 筛选 Providers
- selectedCategoryProvider -> String (当前选中分类)
- searchQueryProvider -> String (搜索关键词)
- filteredInspirationsProvider -> AsyncValue<List<Inspiration>> (筛选后的列表)

## 录音状态 Providers
- recordingStateProvider -> RecordingState
- recordingDurationProvider -> int (秒)
- recordingPathProvider -> String?
- recordingErrorProvider -> String?
- recordingNotifierProvider -> StateNotifier

## AI 状态 Providers
- aiProcessingStateProvider -> AIProcessingState
- aiErrorProvider -> String?

## 便捷方法
- refreshInspirations(ref) - 刷新灵感列表
- refreshCategories(ref) - 刷新分类
- refreshInspirationDetail(ref, id) - 刷新详情
- resetFilters(ref) - 重置筛选
- resetRecordingState(ref) - 重置录音
- resetAIState(ref) - 重置 AI 状态

*/
